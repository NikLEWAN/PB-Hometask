"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/graphql";
exports.ids = ["pages/api/graphql"];
exports.modules = {

/***/ "@prisma/client":
/*!*********************************!*\
  !*** external "@prisma/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ "apollo-server-micro":
/*!**************************************!*\
  !*** external "apollo-server-micro" ***!
  \**************************************/
/***/ ((module) => {

module.exports = require("apollo-server-micro");

/***/ }),

/***/ "(api)/./pages/api/graphql.ts":
/*!******************************!*\
  !*** ./pages/api/graphql.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"config\": () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var apollo_server_micro__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! apollo-server-micro */ \"apollo-server-micro\");\n/* harmony import */ var apollo_server_micro__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(apollo_server_micro__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @prisma/client */ \"@prisma/client\");\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst prisma = new _prisma_client__WEBPACK_IMPORTED_MODULE_1__.PrismaClient();\nconst typeDefs = apollo_server_micro__WEBPACK_IMPORTED_MODULE_0__.gql`\r\n\ttype Contact{\r\n\t\tid: String\r\n\t\tfirstName: String \r\n\t\tlastName: String \r\n\t\tphoneNumber: String \t\t\r\n\t}\r\n\ttype Query{\r\n\t\tcontacts: [Contact]\r\n\t}\r\n\ttype Mutation {\r\n\t\taddContact(firstName: String, lastName: String, phoneNumber: String): Contact\r\n\t\teditContact(id: String, firstName: String, lastName: String, phoneNumber: String): Contact\r\n\t\tdeleteContact(id: String): Contact\r\n\t}\r\n`;\nconst resolvers = {\n    Query: {\n        contacts: (_parent, _args, _context)=>{\n            return prisma.contact.findMany();\n        }\n    },\n    Mutation: {\n        addContact: (_parent, { firstName , lastName , phoneNumber  }, _context)=>{\n            return prisma.contact.create({\n                data: {\n                    firstName,\n                    lastName,\n                    phoneNumber\n                }\n            });\n        },\n        editContact: (_parent, { id , firstName , lastName , phoneNumber  }, _context)=>{\n            return prisma.contact.update({\n                where: {\n                    id\n                },\n                data: {\n                    firstName,\n                    lastName,\n                    phoneNumber\n                }\n            });\n        },\n        deleteContact: (_parent, { id  }, _context)=>{\n            return prisma.contact.delete({\n                where: {\n                    id\n                }\n            });\n        }\n    }\n};\nconst apolloServer = new apollo_server_micro__WEBPACK_IMPORTED_MODULE_0__.ApolloServer({\n    typeDefs,\n    resolvers\n});\nconst handler = apolloServer.createHandler({\n    path: \"/api/graphql\"\n});\nconst config = {\n    api: {\n        bodyParser: false\n    }\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvZ3JhcGhxbC50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBdUQ7QUFDVjtBQVk3QyxNQUFNRyxNQUFNLEdBQUcsSUFBSUQsd0RBQVksRUFBRTtBQUVqQyxNQUFNRSxRQUFRLEdBQUdKLG9EQUFHLENBQUM7QUFpQnJCLE1BQU1LLFNBQVM7SUFDZEMsS0FBSyxFQUFFO1FBQ05DLFFBQVEsRUFBRSxDQUFDQztZQUNWLE9BQU9MO1FBQ1IsQ0FBQzs7SUFFRlUsUUFBUTtRQUNQQyxVQUFVLEVBQUUsQ0FBQ047O2dCQUNrQlc7b0JBQU9KLFNBQVM7b0JBQUVDLFFBQVE7b0JBQUVDLFdBQVc7OztRQUN0RSxDQUFDO1FBQ0RHO1lBQ0MsT0FBT2pCLE1BQU0sQ0FBQ1EsT0FBTyxDQUFDVyxNQUFNLENBQUM7Z0JBQUNDLEtBQUssRUFBRTs7OztvQkFBYVIsU0FBUztvQkFBRUMsUUFBUTtvQkFBRUM7aUJBQVk7YUFBQyxDQUFDO1FBQ3RGLENBQUM7UUFDRE87WUFDQzs7b0JBQXNDSCxFQUFFO2lCQUFDO2FBQUMsQ0FBQztRQUM1QyxDQUFDO0tBQ0Q7Q0FDRDtBQUVELE1BQU1LLFlBQVksR0FBRyxJQUFJekI7SUFBZUcsUUFBUTtJQUFFQyxTQUFTO0NBQUMsQ0FBQztBQUU3RCxNQUFNc0IsT0FBTztJQUFnQ0UsSUFBSSxFQUFFO0NBQWUsQ0FBQztBQUVuRSxPQUFPLE1BQU1DLE1BQU0sR0FBRztJQUFFQyxHQUFHLEVBQUU7UUFBRUMsVUFBVSxFQUFFO0tBQU07Q0FBRTtBQUVuRCIsInNvdXJjZXMiOlsid2VicGFjazovL2dxbC1jcnVkLy4vcGFnZXMvYXBpL2dyYXBocWwudHM/ZWExZCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBncWwsIEFwb2xsb1NlcnZlciB9IGZyb20gJ2Fwb2xsby1zZXJ2ZXItbWljcm8nXHJcbmltcG9ydCB7IFByaXNtYUNsaWVudCB9IGZyb20gJ0BwcmlzbWEvY2xpZW50J1xyXG5cclxuaW50ZXJmYWNlIFByb3Bze1xyXG5cdF9wYXJlbnQ6IGFueVxyXG5cdF9hcmdzOiBvYmplY3RcclxuXHRfY29udGV4dDogYW55XHJcblx0aWQ6IHN0cmluZ1xyXG5cdGZpcnN0TmFtZTogc3RyaW5nXHJcblx0bGFzdE5hbWU6IHN0cmluZ1xyXG5cdHBob25lTnVtYmVyOiBzdHJpbmdcclxufVxyXG5cclxuY29uc3QgcHJpc21hID0gbmV3IFByaXNtYUNsaWVudCgpXHJcblxyXG5jb25zdCB0eXBlRGVmcyA9IGdxbGBcclxuXHR0eXBlIENvbnRhY3R7XHJcblx0XHRpZDogU3RyaW5nXHJcblx0XHRmaXJzdE5hbWU6IFN0cmluZyBcclxuXHRcdGxhc3ROYW1lOiBTdHJpbmcgXHJcblx0XHRwaG9uZU51bWJlcjogU3RyaW5nIFx0XHRcclxuXHR9XHJcblx0dHlwZSBRdWVyeXtcclxuXHRcdGNvbnRhY3RzOiBbQ29udGFjdF1cclxuXHR9XHJcblx0dHlwZSBNdXRhdGlvbiB7XHJcblx0XHRhZGRDb250YWN0KGZpcnN0TmFtZTogU3RyaW5nLCBsYXN0TmFtZTogU3RyaW5nLCBwaG9uZU51bWJlcjogU3RyaW5nKTogQ29udGFjdFxyXG5cdFx0ZWRpdENvbnRhY3QoaWQ6IFN0cmluZywgZmlyc3ROYW1lOiBTdHJpbmcsIGxhc3ROYW1lOiBTdHJpbmcsIHBob25lTnVtYmVyOiBTdHJpbmcpOiBDb250YWN0XHJcblx0XHRkZWxldGVDb250YWN0KGlkOiBTdHJpbmcpOiBDb250YWN0XHJcblx0fVxyXG5gXHJcblxyXG5jb25zdCByZXNvbHZlcnMgPSB7XHJcblx0UXVlcnk6IHtcclxuXHRcdGNvbnRhY3RzOiAoX3BhcmVudCwgX2FyZ3MsIF9jb250ZXh0KSA9PiB7XHJcblx0XHRcdHJldHVybiBwcmlzbWEuY29udGFjdC5maW5kTWFueSgpXHJcblx0XHR9LFxyXG5cdH0sXHJcblx0TXV0YXRpb246IHtcclxuXHRcdGFkZENvbnRhY3Q6IChfcGFyZW50LCB7Zmlyc3ROYW1lLCBsYXN0TmFtZSwgcGhvbmVOdW1iZXJ9LCBfY29udGV4dCkgPT4ge1xyXG5cdFx0XHRyZXR1cm4gcHJpc21hLmNvbnRhY3QuY3JlYXRlKHtkYXRhOiB7Zmlyc3ROYW1lLCBsYXN0TmFtZSwgcGhvbmVOdW1iZXJ9fSlcclxuXHRcdH0sXHJcblx0XHRlZGl0Q29udGFjdDogKF9wYXJlbnQsIHtpZCwgZmlyc3ROYW1lLCBsYXN0TmFtZSwgcGhvbmVOdW1iZXJ9LCBfY29udGV4dCkgPT4ge1xyXG5cdFx0XHRyZXR1cm4gcHJpc21hLmNvbnRhY3QudXBkYXRlKHt3aGVyZToge2lkfSwgZGF0YToge2ZpcnN0TmFtZSwgbGFzdE5hbWUsIHBob25lTnVtYmVyfX0pXHJcblx0XHR9LFxyXG5cdFx0ZGVsZXRlQ29udGFjdDogKF9wYXJlbnQsIHtpZH0sIF9jb250ZXh0KSA9PiB7XHJcblx0XHRcdHJldHVybiBwcmlzbWEuY29udGFjdC5kZWxldGUoe3doZXJlOiB7aWR9fSlcclxuXHRcdH0sXHJcblx0fSxcclxufVxyXG5cclxuY29uc3QgYXBvbGxvU2VydmVyID0gbmV3IEFwb2xsb1NlcnZlcih7IHR5cGVEZWZzLCByZXNvbHZlcnN9KVxyXG5cclxuY29uc3QgaGFuZGxlciA9IGFwb2xsb1NlcnZlci5jcmVhdGVIYW5kbGVyKHsgcGF0aDogXCIvYXBpL2dyYXBocWxcIn0pXHJcblxyXG5leHBvcnQgY29uc3QgY29uZmlnID0geyBhcGk6IHsgYm9keVBhcnNlcjogZmFsc2V9IH1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGhhbmRsZXJcclxuXHJcbiJdLCJuYW1lcyI6WyJncWwiLCJBcG9sbG9TZXJ2ZXIiLCJQcmlzbWFDbGllbnQiLCJwcmlzbWEiLCJ0eXBlRGVmcyIsInJlc29sdmVycyIsIlF1ZXJ5IiwiY29udGFjdHMiLCJfcGFyZW50IiwiX2FyZ3MiLCJfY29udGV4dCIsImNvbnRhY3QiLCJmaW5kTWFueSIsIk11dGF0aW9uIiwiYWRkQ29udGFjdCIsImZpcnN0TmFtZSIsImxhc3ROYW1lIiwicGhvbmVOdW1iZXIiLCJjcmVhdGUiLCJkYXRhIiwiZWRpdENvbnRhY3QiLCJpZCIsInVwZGF0ZSIsIndoZXJlIiwiZGVsZXRlQ29udGFjdCIsImRlbGV0ZSIsImFwb2xsb1NlcnZlciIsImhhbmRsZXIiLCJjcmVhdGVIYW5kbGVyIiwicGF0aCIsImNvbmZpZyIsImFwaSIsImJvZHlQYXJzZXIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/graphql.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/graphql.ts"));
module.exports = __webpack_exports__;

})();