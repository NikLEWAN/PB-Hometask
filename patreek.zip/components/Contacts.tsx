import { useQuery } from '@apollo/client'
import { GET_CONTACTS } from '../graphql/queries'
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';
import PhoneIcon from '@mui/icons-material/Phone';
import Grid from '@mui/material/Grid';


const Contact = ({ id, firstName, lastName, phoneNumber, onDelete, openModal}) => {
  return (
    <Card sx={{ marginTop: '15px' }}>
		<Grid container alignItems="center" justifyContent='space-between' sx={{ padding: '16px' }}>
			<Grid item xs={7}>
				<Typography>
					{firstName} {lastName} 
				</Typography>
				<Grid container direction="row" alignItems="center">
					<Grid item>
						<PhoneIcon sx={{ height: '16px', color: 'text.secondary' }}/>
					</Grid>
					<Grid item>
						<Typography alignItems="center" variant="button" display="block" gutterBottom sx={{ color: 'text.secondary' }}>
							{phoneNumber}
						</Typography>
					</Grid>
				</Grid>
			</Grid>
			<Grid item>
				<Button onClick={() => openModal(id, firstName, lastName, phoneNumber)} size="small">Edit</Button>
				<Button color='warning' onClick={() => onDelete(id)} size="small"><DeleteForeverIcon /></Button>
			</Grid>
		</Grid>
    </Card>
  );
}


const Contacts = ({ onDelete, openModal }) => {
	const {loading, error, data} = useQuery(GET_CONTACTS)
	if(loading){
		return 'loading'
	}
	if(error){
		return 'error'
	}
	return data.contacts.map((contactData) => (
	<Contact onDelete={onDelete} openModal={openModal} {...contactData} key={contactData.id} />
	))
}

export default Contacts